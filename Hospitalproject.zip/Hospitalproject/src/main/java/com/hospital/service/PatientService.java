package com.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.hospital.dao.PatientDao;
import com.hospital.entity.Patient;

@Service
public class PatientService {

	@Autowired
	PatientDao dao;
	
	public List<Patient> getPatientDetails() {
List<Patient>	 list =	dao.getPatientDetails();
		return list;
		
	}

	public List<Patient> insertPatientDetails() {
	List<Patient> list = dao.insertPatientDetails();
	return list;
	}

	public List<Patient> updatePatientDetails() {
		List<Patient> list = dao.updatePatientDetails();
		return list;
	}

	public List<Patient> getPatientDetails1() {
		List<Patient>	 list =	dao.getPatientDetails1();
		return list;
	}

	public List<Patient> getPatientDetails2() {
		List<Patient> list=dao.getPatientDetails2();
		return list;
		
	}

	public List<Patient> getPatientDetails3() {
		List<Patient> list = dao.getPatientDetails3();
		return list;
	}

	public List<Patient> getPatientDetails4() {
		List<Patient> list = dao.getPatientDetails4();
		return list;
	
	}

	public List<Patient> getPatientDetails5() {
		List<Patient> list = dao.getPatientDetails5();
		return list;
	}

	public List<Patient> getPatientDetails6() {
		List<Patient> list = dao.getPatientDetails6();
		return list;
		
	}

	public List<Patient> getPatientDetails7() {
		List<Patient> list = dao.getPatientDetails7();
		return list;
	}

	public List<Patient> getPatientDetails8() {
		List<Patient> list = dao.getPatientDetails8();
		return list;
	}

	public List<Patient> getPatientDetails9() {
		List<Patient> list = dao.getPatientDetails9();
		return list;
	}

	public List<Patient> getPatientDetails10() {
		List<Patient> list = dao.getPatientDetails10();
		return list;
	}

	public List<Patient> getPatientDetails11() {
		List<Patient> list = dao.getPatientDetails11();
		return list;
	}

	public List<Patient> getPatientDetails12() {
		List<Patient> list = dao.getPatientDetails12();
		return list;
	}

	public List<Patient> getPatientDetails13() {
		List<Patient> list = dao.getPatientDetails13();
		return list;
	}

	public List<Patient> getPatientDetails14() {
		List<Patient> list = dao.getPatientDetails14();
		return list;
	}

	public List<Patient> getPatientDetails15() {
		List<Patient> list = dao.getPatientDetails15();
		return list;
	}

	public List<Patient> getPatientDetails16() {
		List<Patient> list = dao.getPatientDetails16();
		return list;
	}

	public List<Patient> getPatientDetails17() {
		List<Patient> list = dao.getPatientDetails17();
		return list;
	}

	public List<Patient> getPatientDetails18() {
		List<Patient> list = dao.getPatientDetails18();
		return list;
	}

	public List<Patient> getPatientDetails19() {
		List<Patient> list = dao.getPatientDetails19();
		return list;
	}

	public List<Patient> getPatientDetails20() {
		List<Patient> list = dao.getPatientDetails20();
		return list;
	}

	public List<Patient> getPatientDetails21() {
		List<Patient> list = dao.getPatientDetails21();
		return list;
	}

	public List<Patient> getPatientDetails22() {
		List<Patient> list = dao.getPatientDetails22();
		return list;
	}

	public List<Patient> getPatientDetails23() {
		List<Patient> list = dao.getPatientDetails23();
		return list;
	}

	public List<Patient> getPatientDetails24() {
	List<Patient> list = dao.getPatientDetails24();
	return list;
	
	}

	public List<Patient> getPatientDetails25() {
		List<Patient> list = dao.getPatientDetails25();
		return list;
	}

	public List<Patient> getPatientDetails26() {
		List<Patient> list = dao.getPatientDetails26();
		return list;
	}

	public List<Patient> getPatientDetails27() {
		List<Patient> list = dao.getPatientDetails27();
		return list;
	}

	public List<Patient> getPatientDetails28() {
		List<Patient> list = dao.getPatientDetails28();
		return list;
	}

	public List<Patient> getPatientDetails29() {
		List<Patient> list = dao.getPatientDetails29();
		return list;
	}

	public List<Patient> getPatientDetails30() {
		List<Patient> list = dao.getPatientDetails30();
		return list;
	}

	public List<Patient> getPatientDetails31() {
		List<Patient> list = dao.getPatientDetails31();
		return list;
	}

	public List<Patient> getPatientDetails32() {
		List<Patient> list = dao.getPatientDetails32();
		return list;
	}

	public List<Patient> getPatientDetails33() {
		List<Patient> list = dao.getPatientDetails33();
		return list;
	}

	public List<Patient> getPatientDetails34() {
		List<Patient> list = dao.getPatientDetails34();
		return list;
	}

	public List<Patient> getPatientDetails35() {
		List<Patient> list = dao.getPatientDetails35();
		return list;
	}

	public List<Patient> getPatientDetails36() {
		List<Patient> list = dao.getPatientDetails36();
		return list;
	}

	public List<Patient> getPatientDetails37() {
		List<Patient> list = dao.getPatientDetails37();
		return list;
	}

	public List<Patient> getPatientDetails38() {
		List<Patient> list = dao.getPatientDetails38();
		return list;
	}

	public List<Patient> getPatientDetails39() {
		List<Patient> list = dao.getPatientDetails39();
		return list;
	}

	public List<Patient> getPatientDetails40() {
		List<Patient> list = dao.getPatientDetails40();
		return list;
	}

	public List<Patient> getPatientDetails41() {
		List<Patient> list = dao.getPatientDetails41();
		return list;
	}

	public List<Patient> getPatientDetails42() {
		List<Patient> list = dao.getPatientDetails42();
		return list;
	}

	public List<Patient> getPatientDetails43() {
		List<Patient> list = dao.getPatientDetails43();
		return list;
	}
}

	
	


	
