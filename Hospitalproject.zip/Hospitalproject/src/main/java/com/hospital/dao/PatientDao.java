package com.hospital.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hospital.entity.Patient;

@Repository
public class PatientDao {
    
	@Autowired
	SessionFactory sf;
	
	//1
	public List<Patient> getPatientDetails() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Patient.class);
		return criteria.list();
		
	}
 //2
	
		
	    public List<Patient> insertPatientDetails() {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Patient.class);
		Patient pt = new Patient();
		pt.setId(4);
		pt.setFname("maria");
		pt.setLname("jhons");
		pt.setDiesease("fever");
		pt.setCity("banglore");
		pt.setMob(1234);
		pt.setLastvisit("thursday");
		pt.setAge(50);
		session.save(pt);
		System.out.println("Data save....");
		return criteria.list();
		
	}

	    //3

		public List<Patient> updatePatientDetails() {
			Session session = sf.openSession();
			Transaction transaction = session.beginTransaction();
			Criteria criteria = session.createCriteria(Patient.class);
			Patient pt = new Patient();
			pt.setId(4);
			pt.setFname("maria");
			pt.setLname("jhons");
			pt.setDiesease("fever");
			pt.setCity("banglore");
			pt.setMob(1234);
			pt.setLastvisit("friday");
			pt.setAge(55);
			session.update(pt);
			System.out.println("Data update....");
			return criteria.list();
			
		}

//4
		public List<Patient> getPatientDetails1() {
	    Session session = sf.openSession();
	    Transaction transaction = session.beginTransaction();
	    Criteria criteria = session.createCriteria(Patient.class);
	    criteria.add(Restrictions.gt("id", 1));
	   	return criteria.list();
		}

//5
		public List<Patient> getPatientDetails2() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.lt("id", 3));
		   	return criteria.list();
			}
   
		//6

		public List<Patient> getPatientDetails3() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.le("id",3));
		   	return criteria.list();
			}

//7
		public List<Patient> getPatientDetails4() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.like("diesease", "maleria"));
		   	return criteria.list();
			
		}

//8
		public List<Patient> getPatientDetails5() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.between("id",2,5));
		   	return criteria.list();
			
		
		}

//9
		public List<Patient> getPatientDetails6() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.ge("age", 35));
		   	return criteria.list();
			
		}
			//10


		public List<Patient> getPatientDetails7() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.like("city", "pune"));
		   	return criteria.list();
			
		}

//11
		public List<Patient> getPatientDetails8() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.idEq(3));
		   	return criteria.list();
			
		}
		//12


		public List<Patient> getPatientDetails9() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.idEq(3));
		   	return criteria.list();
		   	
		}
		//13


		public List<Patient> getPatientDetails10() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.lt("id", 4));
		   	return criteria.list();

		}
		//14


		public List<Patient> getPatientDetails11() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.eqOrIsNull("city", "mumbai"));
		   	return criteria.list();
		}

//15
		public List<Patient> getPatientDetails12() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.in("age", 55));
		   	return criteria.list();
		}

//16
		public List<Patient> getPatientDetails13() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.ilike("lastvisit", "monday"));
		   	return criteria.list();
		}

//17
		public List<Patient> getPatientDetails14() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.eq("city", "banglore"));
		   	return criteria.list();
		}
		//18


		public List<Patient> getPatientDetails15() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.between("age", 30, 40));
		    return criteria.list();
		}

//19
		public List<Patient> getPatientDetails16() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.in("lname","reddy"));
		    return criteria.list();
		}

//20
		public List<Patient> getPatientDetails17() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.like("lname", "kale"));
		    return criteria.list();
		}

//21
		public List<Patient> getPatientDetails18() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.gt("lastvisit", "Tuesday"));
		    return criteria.list();
		}

//22
		public List<Patient> getPatientDetails19() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.lt("city", "nagpur"));
		    return criteria.list();
		}

//23
		public List<Patient> getPatientDetails20() {
			Session session = sf.openSession();
			Transaction transaction = session.beginTransaction();
			Criteria criteria = session.createCriteria(Patient.class);
			Patient pt = new Patient();
			pt.setId(5);
			pt.setFname("babita");
			pt.setLname("iyer");
			pt.setDiesease("tb");
			pt.setCity("kolkata");
			pt.setMob(1235);
			pt.setLastvisit("Thursday");
			pt.setAge(26);
			session.saveOrUpdate(pt);
			System.out.println("Data save or update....");
			return criteria.list();
		}
		//24


		public List<Patient> getPatientDetails21() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.isNotNull("city"));
		    return criteria.list();
		}

//25
		public List<Patient> getPatientDetails22() {
			Session session = sf.openSession();
			Transaction transaction = session.beginTransaction();
			Criteria criteria = session.createCriteria(Patient.class);
			Patient pt = new Patient();
			pt.setId(5);
			pt.setFname("prisha");
			pt.setLname("gupta");
			pt.setDiesease("covid");
			pt.setCity("chandrapur");
			pt.setMob(1236);
			pt.setLastvisit("Sunday");
			pt.setAge(27);
			session.update(pt);
			System.out.println("Data update....");
			return criteria.list();
		}

//26
		public List<Patient> getPatientDetails23() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.between("age", 27, 40));
		    return criteria.list();
		}
//27

		public List<Patient> getPatientDetails24() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.like("city", "kolkata"));
		    return criteria.list();
		}
//28

		public List<Patient> getPatientDetails25() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.idEq(1));
		    return criteria.list();
		}
		//29


		public List<Patient> getPatientDetails26() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.in("lname", "gupta"));
		    return criteria.list();
		}
//30

		public List<Patient> getPatientDetails27() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.between("mob", 1234, 1236));
		    return criteria.list();
		}
//31

		public List<Patient> getPatientDetails28() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.lt("id", 4));
		    return criteria.list();
		}
		//32


		public List<Patient> getPatientDetails29() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.gt("age", 30));
		    return criteria.list();
		}

//33
		public List<Patient> getPatientDetails30() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.in("fname", "priya"));
		    return criteria.list();
		}

//34
		public List<Patient> getPatientDetails31() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.isNull("lname"));
		    return criteria.list();
		}

//35
		public List<Patient> getPatientDetails32() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.eq("id", 1));
		    return criteria.list();
		}
//36

		public List<Patient> getPatientDetails33() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.like("fname", "riya"));
		    return criteria.list();
		}

//37
		public List<Patient> getPatientDetails34() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.like("diesease", "tb"));
		    return criteria.list();
		}

//38
		public List<Patient> getPatientDetails35() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.le("lastvisit", "Thursday"));
		    return criteria.list();
		}
//39


		public List<Patient> getPatientDetails36() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.ge("fname", "babita"));
		    return criteria.list();
		}

//40
		public List<Patient> getPatientDetails37() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.like("city", "chandrapur"));
		    return criteria.list();
		}
//41

		public List<Patient> getPatientDetails38() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.in("lname", "iyer"));
		    return criteria.list();
		}

//42
		public List<Patient> getPatientDetails39() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.gt("mob", 1234));
		    return criteria.list();
		}

//43
		public List<Patient> getPatientDetails40() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.lt("mob", 9865));
		    return criteria.list();
		}
//44


		public List<Patient> getPatientDetails41() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.between("diesease", "maleria", "covid"));
		    return criteria.list();
		}
		//45


		public List<Patient> getPatientDetails42() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.in("lastvisit", "Sunday"));
		    return criteria.list();
		}
		//46


		public List<Patient> getPatientDetails43() {
			Session session = sf.openSession();
		    Transaction transaction = session.beginTransaction();
		    Criteria criteria = session.createCriteria(Patient.class);
		    criteria.add(Restrictions.like("lastvisit", "Monday"));
		    return criteria.list();
		}
		
		
		}
		
		
		
		



		


		
		
		
		
		
			
		


