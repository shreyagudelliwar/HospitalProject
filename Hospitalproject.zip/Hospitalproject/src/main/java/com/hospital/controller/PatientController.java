package com.hospital.controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Patient;
import com.hospital.service.PatientService;

@RestController
public class PatientController {
	
	@Autowired
	PatientService service;
	
	@GetMapping("/allpatient")
	public List<Patient>getPatientDetails() {
		List<Patient> list = service.getPatientDetails();
		
		return list;
	}
    
	@PostMapping("/insertpatient")
	public List<Patient> insertPatientDetails(){
		List<Patient> list =service.insertPatientDetails();
		return list;
		
	}
	
	@PutMapping("/updatepatient")
	public List<Patient> updatePatientDetails(){
		List<Patient>list = service.updatePatientDetails();
		return list;
		
	}
	
	@GetMapping("/allpatient1")
	public List<Patient>getPatientDetails1() {
		List<Patient> list = service.getPatientDetails1();
		return list;	
		
		
	}
	
	@GetMapping("/allpatient2")
	public List<Patient>getPatientDetails2() {
		List<Patient> list = service.getPatientDetails2();
		return list;
	}
	@GetMapping("/allpatient3")
	public List<Patient>getPatientDetails3() {
		List<Patient> list = service.getPatientDetails3();
		return list;

	}
	@GetMapping("/allpatient4")
	public List<Patient>getPatientDetails4() {
		List<Patient> list = service.getPatientDetails4();
		return list;
}
	@GetMapping("/allpatient5")
	public List<Patient>getPatientDetails5() {
		List<Patient> list = service.getPatientDetails5();
		return list;
}
	@GetMapping("/allpatient6")
	public List<Patient>getPatientDetails6() {
		List<Patient> list = service.getPatientDetails6();
		return list;
}
	@GetMapping("/allpatient7")
	public List<Patient>getPatientDetails7() {
		List<Patient> list = service.getPatientDetails7();
		return list;
}
	@GetMapping("/allpatient8")
	public List<Patient>getPatientDetails8() {
		List<Patient> list = service.getPatientDetails8();
		return list;
}
	@GetMapping("/allpatient9")
	public List<Patient>getPatientDetails9() {
		List<Patient> list = service.getPatientDetails9();
		return list;
}
	@GetMapping("/allpatient10")
	public List<Patient>getPatientDetails10() {
		List<Patient> list = service.getPatientDetails10();
		return list;
}
	@GetMapping("/allpatient11")
	public List<Patient>getPatientDetails11() {
		List<Patient> list = service.getPatientDetails11();
		return list;
}
	@GetMapping("/allpatient12")
	public List<Patient>getPatientDetails12() {
		List<Patient> list = service.getPatientDetails12();
		return list;
}
	@GetMapping("/allpatient13")
	public List<Patient>getPatientDetails13() {
		List<Patient> list = service.getPatientDetails13();
		return list;
}
	
		@GetMapping("/allpatient14")
	public List<Patient>getPatientDetails14() {
		List<Patient> list = service.getPatientDetails14();
		return list;
}
		@GetMapping("/allpatient15")
		public List<Patient>getPatientDetails15() {
			List<Patient> list = service.getPatientDetails15();
			return list;
	
}
		@GetMapping("/allpatient16")
		public List<Patient>getPatientDetails16() {
			List<Patient> list = service.getPatientDetails16();
			return list;
}
		@GetMapping("/allpatient17")
		public List<Patient>getPatientDetails17() {
			List<Patient> list = service.getPatientDetails17();
			return list;
}
		@GetMapping("/allpatient18")
		public List<Patient>getPatientDetails18() {
			List<Patient> list = service.getPatientDetails18();
			return list;
		
}
		@GetMapping("/allpatient19")
		public List<Patient>getPatientDetails19() {
			List<Patient> list = service.getPatientDetails19();
			return list;
		
}
		@GetMapping("/allpatient20")
		public List<Patient>getPatientDetails20() {
			List<Patient> list = service.getPatientDetails20();
			return list;
		
}
		@GetMapping("/allpatient21")
		public List<Patient>getPatientDetails21() {
			List<Patient> list = service.getPatientDetails21();
			return list;
}
		@GetMapping("/allpatient22")
		public List<Patient>getPatientDetails22() {
			List<Patient> list = service.getPatientDetails22();
			return list;
}
		@GetMapping("/allpatient23")
		public List<Patient>getPatientDetails23() {
			List<Patient> list = service.getPatientDetails23();
			return list;
		
}
		@GetMapping("/allpatient24")
		public List<Patient>getPatientDetails24() {
			List<Patient> list = service.getPatientDetails24();
			return list;
}
		@GetMapping("/allpatient25")
		public List<Patient>getPatientDetails25() {
			List<Patient> list = service.getPatientDetails25();
			return list;
}
		@GetMapping("/allpatient26")
		public List<Patient>getPatientDetails26() {
			List<Patient> list = service.getPatientDetails26();
			return list;
}
		@GetMapping("/allpatient27")
		public List<Patient>getPatientDetails27() {
			List<Patient> list = service.getPatientDetails27();
			return list;
}
		@GetMapping("/allpatient28")
		public List<Patient>getPatientDetails28() {
			List<Patient> list = service.getPatientDetails28();
			return list;
}

		@GetMapping("/allpatient29")
		public List<Patient>getPatientDetails29() {
			List<Patient> list = service.getPatientDetails29();
			return list;
		
}
		@GetMapping("/allpatient30")
		public List<Patient>getPatientDetails30() {
			List<Patient> list = service.getPatientDetails30();
			return list;
}
		@GetMapping("/allpatient31")
		public List<Patient>getPatientDetails31() {
			List<Patient> list = service.getPatientDetails31();
			return list;
}
		@GetMapping("/allpatient32")
		public List<Patient>getPatientDetails32() {
			List<Patient> list = service.getPatientDetails32();
			return list;
}
		@GetMapping("/allpatient33")
		public List<Patient>getPatientDetails33() {
			List<Patient> list = service.getPatientDetails33();
			return list;
}
		@GetMapping("/allpatient34")
		public List<Patient>getPatientDetails34() {
			List<Patient> list = service.getPatientDetails34();
			return list;
}
		@GetMapping("/allpatient35")
		public List<Patient>getPatientDetails35() {
			List<Patient> list = service.getPatientDetails35();
			return list;
}
		@GetMapping("/allpatient36")
		public List<Patient>getPatientDetails36() {
			List<Patient> list = service.getPatientDetails36();
			return list;
}
		@GetMapping("/allpatient37")
		public List<Patient>getPatientDetails37() {
			List<Patient> list = service.getPatientDetails37();
			return list;
}
		@GetMapping("/allpatient38")
		public List<Patient>getPatientDetails38() {
			List<Patient> list = service.getPatientDetails38();
			return list;	
}
		@GetMapping("/allpatient39")
		public List<Patient>getPatientDetails39() {
			List<Patient> list = service.getPatientDetails39();
			return list;	
}
		@GetMapping("/allpatient40")
		public List<Patient>getPatientDetails40() {
			List<Patient> list = service.getPatientDetails40();
			return list;	
}
		@GetMapping("/allpatient41")
		public List<Patient>getPatientDetails41() {
			List<Patient> list = service.getPatientDetails41();
			return list;	
}	
		@GetMapping("/allpatient42")
		public List<Patient>getPatientDetails42() {
			List<Patient> list = service.getPatientDetails42();
			return list;		
}
		@GetMapping("/allpatient43")
		public List<Patient>getPatientDetails43() {
			List<Patient> list = service.getPatientDetails43();
			return list;				
}
}


